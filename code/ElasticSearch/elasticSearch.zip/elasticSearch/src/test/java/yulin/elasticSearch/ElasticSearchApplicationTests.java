package yulin.elasticSearch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElasticSearchApplicationTests {

	@Test
	void contextLoads() {
	}

}
